// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyBrh2la_UWVSepIO-UCK21sILR27LP2LXk',
    authDomain: 'cartasbar-ad70c.firebaseapp.com',
    databaseURL: 'https://cartasbar-ad70c.firebaseio.com',
    projectId: 'cartasbar-ad70c',
    storageBucket: 'cartasbar-ad70c.appspot.com',
    messagingSenderId: '954510398095',
    appId: '1:954510398095:web:72650a996fdd376d38d6fa',
    measurementId: 'G-W0WQTT3YS1'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
