export interface User {
  direccion: string;
  email: string;
  emailVerified: boolean;
  image: File;
  name: string;
  telefono: string;
  uid: string;
  //displayName: string;
}
