export class Category {
  $key: string;
  id: string;
  category: string;
}
